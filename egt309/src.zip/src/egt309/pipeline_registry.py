"""Project pipelines."""
from kedro.pipeline import Pipeline
from egt309.pipelines import data_prep as dp
from egt309.pipelines import model_train as mt

def register_pipelines() -> dict[str, Pipeline]:
    """Register the project's pipelines.

    Returns:
        A mapping from pipeline names to `Pipeline` objects.
    """
    
    # 1. Define the Pipeline Objects
    data_prep_pipeline = dp.create_pipeline()
    model_train_pipeline = mt.create_pipeline()

    return {
        # 2. Register the Default Pipeline (runs everything)
        "__default__": data_prep_pipeline + model_train_pipeline, 
        
        # 3. Register the Individual Pipelines for targeted runs
        "data_prep": data_prep_pipeline,
        "data_science": model_train_pipeline
    }