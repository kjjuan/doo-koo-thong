"""
This is a boilerplate pipeline 'reporting'
generated using Kedro 1.0.0
"""

from kedro.pipeline import Node, Pipeline  # noqa


def create_pipeline(**kwargs) -> Pipeline:
    return Pipeline([])
