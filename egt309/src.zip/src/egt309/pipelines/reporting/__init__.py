"""
This is a boilerplate pipeline 'reporting'
generated using Kedro 1.0.0
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]

__version__ = "0.1"
